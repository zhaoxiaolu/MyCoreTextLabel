//
//  MYAttributeModel.m
//  图文混排demo
//
//  Created by 孟遥 on 2017/2/8.
//  Copyright © 2017年 孟遥. All rights reserved.
//

#import "MYAttributeModel.h"

@implementation MYAttributeModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}



@end

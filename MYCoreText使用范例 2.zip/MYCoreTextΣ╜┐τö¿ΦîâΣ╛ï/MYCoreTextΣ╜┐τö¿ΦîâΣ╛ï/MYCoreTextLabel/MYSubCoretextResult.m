//
//  MYSubCoretextResult.m
//  图文混排demo
//
//  Created by 孟遥 on 2017/2/12.
//  Copyright © 2017年 孟遥. All rights reserved.
//

#import "MYSubCoretextResult.h"

@implementation MYSubCoretextResult

@end


@implementation MYLinkModel


@end

//
//  showCell.h
//  MYCoreText使用范例
//
//  Created by 孟遥 on 2017/2/16.
//  Copyright © 2017年 mengyao. All rights reserved.
//

#import <UIKit/UIKit.h>

@class tableViewModel;

@interface showCell : UITableViewCell

@property (nonatomic, strong) tableViewModel *model;

@end
